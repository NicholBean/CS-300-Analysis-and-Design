#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <algorithm>

// Nicholas Bean
// Project Two - Advising Assistance Software created using a Hash Table

using namespace std;


// Course Class
class Course {
public:
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;

    Course() {}
    Course(string number, string title, vector<string> prereqs) {
        courseNumber = number;      // Course Number
        courseTitle = title;        // Course Title
        prerequisites = prereqs;    // Prerequisites
    }
};

// Global Hash Table
unordered_map<string, Course> courseTable;

// Load Courses Function
void loadCourses(const string& filename) {
    ifstream file(filename);

    // If file cannot be openned
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    courseTable.clear();

    // Load file
    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string courseNumber, courseTitle, prereq;
        vector<string> prereqs;

        // Parse first two fields
        getline(ss, courseNumber, ',');
        getline(ss, courseTitle, ',');

        // Parse remaining fields as prerequisites
        while (getline(ss, prereq, ',')) {
            if (!prereq.empty())
                prereqs.push_back(prereq);
        }

        Course c(courseNumber, courseTitle, prereqs);
        courseTable[courseNumber] = c;
    }

    // Courses loaded
    cout << "Data structure loaded successfully!" << endl;
    file.close();
}

// Print Sorted Course List Function
void printCourseList() {

    // If courses are not loaded
    if (courseTable.empty()) {
        cout << "Error: No courses loaded. Please load data first.\n";
        return;
    }

    // Load courses alphanumeric
    vector<string> keys;
    for (const auto& pair : courseTable)
        keys.push_back(pair.first);

    sort(keys.begin(), keys.end());

    cout << "Here is a sample schedule:\n";
    for (const string& key : keys) {
        cout << key << ", " << courseTable[key].courseTitle << endl;
    }
}

// Print Individual Course Info Function
void printCourseInfo() {

    // If courses are not loaded
    if (courseTable.empty()) {
        cout << "Error: No courses loaded. Please load data first.\n";
        return;
    }

    string courseNum;
    cout << "What course do you want to know about? ";
    cin.ignore(); // Clear leftover newline from previous input
    getline(cin, courseNum); // Read full line including spaces

    // Convert input to uppercase
    for (auto& c : courseNum) c = toupper(c);

    // Print prerequisites of selected course
    if (courseTable.find(courseNum) != courseTable.end()) {
        Course c = courseTable[courseNum];
        cout << c.courseNumber << ", " << c.courseTitle << endl;

        // If there are no prerequisites
        cout << "Prerequisites: ";
        if (c.prerequisites.empty()) {
            cout << "None";
        }
        else {
            for (size_t i = 0; i < c.prerequisites.size(); ++i) {
                string prereqNum = c.prerequisites[i];
                cout << prereqNum;

                // Print the course and title of the prerequisite if it exists
                if (courseTable.find(prereqNum) != courseTable.end()) {
                    cout << " " << courseTable[prereqNum].courseTitle << "";
                }

                if (i < c.prerequisites.size() - 1)
                    cout << ", ";
            }
        }
        cout << endl;
    }
    // If course does not exist
    else {
        cout << "Course not found.\n";
    }
}

// Menu 
void menu() {
    int choice;

    cout << "Welcome to the course planner." << endl;

    // Menu Options
    do {
        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl;
        cout << "What would you like to do? ";

        string rawInput;
        getline(cin, rawInput);  // Read entire line including spaces

        // Validate input is numeric
        bool isNumber = true;
        for (char c : rawInput) {
            if (!isdigit(c)) isNumber = false;
        }

        // If there are invalid inputs
        if (!isNumber) {
            cout << rawInput << " is not a valid option." << endl;
            continue;
        }

        // Input
        choice = stoi(rawInput);

        switch (choice) {
        case 1: {
            // User must input file (CS 300 ABCU_Advising_Program_Input.csv)
            string filename;
            cout << "Enter file name to load: ";
            getline(cin, filename);
            loadCourses(filename);
            break;
        }
        case 2:
            // Print Course in Alphanumeric order
            printCourseList();
            break;
        case 3:
            // Print prerequisites of course
            printCourseInfo();
            break;
        case 9:
            // Exit
            cout << "Thank you for using the course planner!" << endl;
            break;
        default:
            // If choice is not 1, 2, 3, 9
            cout << choice << " is not a valid option." << endl;
        }

        // Loop until Exit is selected
    } while (choice != 9);
}

// Main Function
int main() {
    menu();
    return 0;
}